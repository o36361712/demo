export default function Admin() {
    return(
<main><ul>
        <li>ID Статус Адрес User Caunt
            <select>
                <option>Новые</option>
                <option>Обработка</option>
                <option>Доставлен</option>
            </select>
        </li>
        <li>ID Статус Адрес User Caunt
            <select>
                <option>Новые</option>
                <option>Обработка</option>
                <option>Доставлен</option>
            </select>
        </li>
        <li>ID Статус Адрес User Caunt
            <select>
                <option>Новые</option>
                <option>Обработка</option>
                <option>Доставлен</option>
            </select>
        </li>


    </ul></main>
    )
}