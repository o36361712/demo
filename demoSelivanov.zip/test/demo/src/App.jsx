import { useState } from 'react'
import { Router, Routes, Route } from 'react-router-dom'
import LoginPage from "./LoginPage.jsx"
import RegistrationPage from "./RegistrationPage.jsx"
import './index.css'
import Navv from './Navv.jsx'
import MyOrder from './MyOrder.jsx'
import Catalog from './Catalog.jsx'
import Dairy from './Dairy.jsx'
import Basket from './Basket.jsx'
import Admin from './Admin.jsx'



function App() {
  return(
<Routes>
  <Route path="/Login" element={<LoginPage/>} />
  <Route path="/Registration" element={<RegistrationPage/>} />
  <Route path="/" element={<><Navv/><MyOrder/></>} />
  <Route path="/MyOrder" element={<><Navv/><MyOrder/></>} />
  <Route path="/Catalog" element={<><Navv/><Catalog/></>} />
  <Route path="/Dairy" element={<><Navv/><Dairy/></>} />
  <Route path="/Basket" element={<><Navv/><Basket/></>} />
  <Route path='/Admin' element={<Admin/>}/>
</Routes>
  )
}

export default App
