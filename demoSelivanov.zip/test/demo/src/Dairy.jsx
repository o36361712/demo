export default function Dairy() {
    return(
        <>
        <div className="CatlogImg">
        <div className="OrderList">
    <ul>
        <li>Товар<input type="number"/></li>
        <li>Товар<input type="number"/></li>
        <li>Товар<input type="number"/></li>
        <li>Товар<input type="number"/></li>
        <li>Товар<input type="number"/></li>

    </ul>
</div>
        </div>
        </>
    );
}