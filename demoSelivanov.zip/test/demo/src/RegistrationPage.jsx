export default function RegistrationPage() {
    function Reg(){

    }
    return (
        <>
<main>
<h1>Регистрация</h1>
<form>
<input name='login' required type="text" placeholder="ЛОГИН"></input>
<input name='passs'required type="password"placeholder="Пароль"></input>
<input name='FIO'required type="text" placeholder="ФИО"></input>
<input required type="tel" placeholder="телефон"></input>
<input required type="email"placeholder="Почта"></input>
<button>Регистрация</button>
</form>
</main>
        </>
    );
}