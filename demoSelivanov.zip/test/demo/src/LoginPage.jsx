import { useEffect, useState } from "react";

export default function LoginPage() {
// const [name, setname] = useState();
// useEffect(
//     fetch('')
//     .then(Response => Response.json())
//     .then()
// ),[];
   
    return (
        <>
<main>
<h1>Авторизация</h1>
<form>
<input name='Login' type="text"placeholder="ЛОГИН"></input>
<input name='Password' type="password" placeholder="Пароль"></input>
<button type="submit">Авторизация</button>
</form>
</main>
        </>
    );
}