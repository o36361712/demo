export default function MyOrder () {
    return(
<>
<main>
<button className="orederButt">Новый заказ</button>
<div className="OrderList">
    <ul>
        <li>ID Статус Адрес</li>
        <li>ID Статус Адрес</li>
        <li>ID Статус Адрес</li>
        <li>ID Статус Адрес</li>
        <li>ID Статус Адрес</li>
    </ul>
</div>
</main>
</>
    );
}