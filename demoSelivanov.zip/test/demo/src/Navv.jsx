import logo from '../public/logo.png'
import { Link } from "react-router-dom";

export default function Navv(){
    return(
<nav>
    <div className='NavLCon'>
        <img src={logo}/>
        <h2>Авоська</h2>
    </div>
    <div className='NavRCon'>
        <Link to="/Basket">Корзина</Link>
        <Link to="/Orders">Мои заказы</Link>
        <Link to="/Exit">Выход</Link>
    </div>
</nav>
    );
}