import { Link } from "react-router-dom";
import img1 from '../public/1.png'
import img2 from '../public/2.png'
import img3 from '../public/3.png'
import img4 from '../public/4.png'
import img5 from '../public/5.png'
import img6 from '../public/6.png'
import img7 from '../public/7.png'
import img8 from '../public/8.png'
import img9 from '../public/9.png'

export default function Catalog() {
    return (<div className="CatlogImg">
<Link to="/dairy"><img src={img1}></img></Link>
<Link to="/1"><img src={img2}></img></Link>
<Link to="/1"><img src={img3}></img></Link>
<Link to="/1"><img src={img4}></img></Link>
<Link to="/1"><img src={img5}></img></Link>
<Link to="/1"><img src={img6}></img></Link>
<Link to="/1"><img src={img7}></img></Link>
<Link to="/1"><img src={img8}></img></Link>
<Link to="/1"><img src={img9}></img></Link>
</div>
    );
}