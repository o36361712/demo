export default function Basket() {
    return (
<main>
<h1>Формирование заказа</h1>

    <form>
    <div className="OrderList"><li>Товар<input type="number"/></li>
    <li>Товар<input type="number"/></li>
    <li>Товар<input type="number"/></li>
    <li>Товар<input type="number"/></li>
    </div>
    <input type="text" placeholder="АДРЕС"></input>
    <button>Оформить</button>
    </form>
</main>
    );
}