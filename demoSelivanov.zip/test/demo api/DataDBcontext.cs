﻿using demo;
using Microsoft.EntityFrameworkCore;

namespace demo
{
    public class DataDBcontext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseNpgsql("Host = 192.168.142.50; Port = 5432; DataBase = SelAVDB; Username = demka; password = demka_123");
        public DbSet<Roles> Roles { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Statuss> Statuss { get; set; }
        public DbSet<ProductTypes> ProductTypes { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<Order> Order { get; set; }
    }                                             
}
