﻿namespace demo
{
    public class Roles
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
    public class Users
    {
        public int UserID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }    
        public string Email { get; set; }
        public string Phone { get; set; }
        public int RoleId { get; set; } 
        public Roles Role { get; set; }
    }
    public class Statuss
    {
        public int StatusId { get; set; }
        public string Status { get; set; }    
    }
    public class ProductTypes
    {
        public int ProductTypeId { get; set; }
        public string ProductType { get; set; }
    }
    public class Products
    {
        public int ProductId { get; set;}
        public string ProductTypeId { get; set; }
        public ProductTypes ProductType { get; set; }
    }
    public class Order
    {
        public int OrderId { get; set; }
        public string Address { get; set; }
        public int User { get; set; }
        public Users Users { get; set; }
        public List<Products> Products { get; set; }

    }
}

